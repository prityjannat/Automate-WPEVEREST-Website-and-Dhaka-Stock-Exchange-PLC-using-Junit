import org.junit.jupiter.api.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class BasicJunit {
    WebDriver driver;
    @BeforeAll
    public void setup(){
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
    }
    @DisplayName("Check the title")
    @Test
    public void assignment(){
        driver.get("https://demo.wpeverest.com/user-registration/guest-registration-form/");
    }
    @Test
    public void visitWebsite(){
        driver.get("https://demoqa.com/");
        String actualResult = driver.getTitle();
        String expectedResult = "DEMOQA";
        Assertions.assertEquals(actualResult,expectedResult);
    }
    @DisplayName("Registration Form")
    @Test
    public void submitButton(){
        driver.get("https://demoqa.com/text-box");
        driver.findElement(By.id("userName")).sendKeys("Afrina Prity");
        driver.findElement(By.id("userEmail")).sendKeys("afrina@gmail.com");
        driver.findElement(By.id("currentAddress")).sendKeys("Gulshan");
        driver.findElement(By.id("permanentAddress")).sendKeys("Dhaka");

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,500)");

        driver.findElement(By.id("submit")).click();

        List<WebElement> element = driver.findElements(By.tagName("p"));
        String name = element.get(0).getText();
        String email = element.get(1).getText();
        String currentAddress = element.get(2).getText();
        String permanentAddress = element.get(3).getText();

        Assertions.assertTrue(name.contains("Afrina Prity"));
        Assertions.assertTrue(email.contains("afrina@gmail.com"));
        Assertions.assertTrue(currentAddress.contains("Gulshan"));
        Assertions.assertTrue(permanentAddress.contains("Dhaka"));
    }
    @Test
    public void click(){
        driver.get("https://demoqa.com/buttons");
        Actions actions = new Actions(driver);
        actions.doubleClick(driver.findElement(By.id("doubleClickBtn"))).perform();
        actions.contextClick(driver.findElement(By.id("rightClickBtn"))).perform();
        List<WebElement> button = driver.findElements(By.tagName("button"));
        actions.click(button.get(3)).perform();
    }
    @Test
    public void alertHandle(){
        driver.get("https://demoqa.com/alerts");
        driver.findElement(By.id("alertButton")).click();
        driver.switchTo().alert().accept();
    }
    @Test
    public void datePicker(){
        driver.get("https://demoqa.com/date-picker");
        WebElement element = driver.findElement(By.id("datePickerMonthYearInput"));
        element.click();
        element.sendKeys(Keys.CONTROL+"a");
        element.sendKeys(Keys.BACK_SPACE);
        element.sendKeys("07/12/2025");
        element.sendKeys(Keys.ENTER);
    }
    @Test
    public void dropdown(){
        driver.get("https://demoqa.com/select-menu");
//        Select select = new Select(driver.findElement(By.id("oldSelectMenu")));
//        select.selectByVisibleText("Green");
        List<WebElement> elements = driver.findElements(By.className("css-1hwfws3"));
        elements.get(1).click();
        Actions action = new Actions(driver);
        action.sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).perform();
    }
    @Test
    public void handleMultipleTab() throws InterruptedException {
        driver.get("https://demoqa.com/browser-windows");
        driver.findElement(By.id("tabButton")).click();
        Thread.sleep(3000);
        ArrayList arrayList = new ArrayList(driver.getWindowHandles());
        System.out.println(arrayList);
        driver.switchTo().window((String) arrayList.get(1));
        String heading = driver.findElement(By.id("sampleHeading")).getText();
        System.out.println(heading);
        driver.close();
        driver.switchTo().window((String) arrayList.get(0));

    }
    @Test
    public void uploadFile(){
        driver.get("https://demoqa.com/upload-download");
        driver.findElement(By.id("uploadFile")).sendKeys(System.getProperty("user.dir")+"/src/test/resources/image.png");
    }
    @Test
    public void table(){
        driver.get("https://demoqa.com/webtables");
        WebElement table = driver.findElement(By.className("rt-tbody"));
        List<WebElement> allrows = table.findElements(By.cssSelector("[role = rowgroup]"));
        for (WebElement row : allrows){
            List<WebElement> allcolumn = row.findElements(By.cssSelector("[role = gridcell]"));
            for (WebElement columns: allcolumn){
                System.out.println(columns.getText());
            }
        }
    }
    @Test
    public void download(){
        driver.get("https://demoqa.com/upload-download");
        driver.findElement(By.id("downloadButton")).click();
    }
    @AfterAll
    public void closeTab(){
        driver.quit();
    }
}
